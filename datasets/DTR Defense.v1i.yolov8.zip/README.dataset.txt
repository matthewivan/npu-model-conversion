# DTR Defense > 2026-10-29 8:18pm
https://universe.roboflow.com/rabid/dtr-defense

Provided by a Roboflow user
License: CC BY 4.0

Dataset/Model to detect red/blue ballons for our DTR class